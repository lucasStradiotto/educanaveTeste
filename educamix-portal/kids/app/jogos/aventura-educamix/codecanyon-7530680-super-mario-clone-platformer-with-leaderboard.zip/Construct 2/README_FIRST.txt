Note for the Google Play Games Version.

#1 - The preview on the browser will not work. You need to export the project to CocoonJS (Importand! Uncheck minify script!) and test this file with the Launcher App (for android & IOS)

Android: https://play.google.com/store/apps/details?id=com.ideateca.cocoonjslauncher
ITunes: https://itunes.apple.com/de/app/cocoonjs-by-ludei/id519623307?mt=8

#2 - You need to Upload your App to the Google Play Store and set up the Leaderboard function 

You will find the docs under http://envato.wdbase.de/documentation/#cat-5

#3 - You need to update the CocoonJS Plugin BEFORE you open the project!

Check the docs first! http://envato.wdbase.de/documentation/#document-10